/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectofinal2;

import javax.swing.JOptionPane;

/**
 *
 * @author azoac
 */
public class ProyectoFinal2 {

public static void main(String[] args) {
          
        
        mostrarMenuPrincipal();
    }

     public static void mostrarMenuPrincipal() {
        BancoGestor gestorBanco = new BancoGestor();

        mostrarMenuPrincipal(gestorBanco);
    }

    
    public static void mostrarMenuPrincipal(BancoGestor gestor) {
        String[] opciones = {"Menú Banco", "Clientes", "Salir"};
     
        boolean continuar = true;
        while (continuar) {
            int seleccion = JOptionPane.showOptionDialog(
                    null,
                    "Selecciona una opción:",
                    "Hiperbanco - Menú Principal",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
            );

            switch (seleccion) {
                case 0: // "Menú Banco" 
                    BancoMenu.mostrarMenuBancario(gestor);
                    break;
                case 1: // "Clientes" 
                    Cliente.iniciarSesion(gestor); // Llamada al método estático en la clase Cliente
                    break;
                case 2: // "Salir"
                    JOptionPane.showMessageDialog(null, "Saliendo del programa. ¡Hasta pronto!");
                    continuar = false; 
                    break;
               
                default:
                    JOptionPane.showMessageDialog(null, "Opción no reconocida. Por favor, selecciona una opción válida.");
                    break;
            }
        }
    }
}
