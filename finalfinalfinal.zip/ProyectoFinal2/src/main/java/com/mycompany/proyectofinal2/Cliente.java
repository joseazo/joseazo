/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal2;

/**
 *
 * @author azoac
 */
import java.time.LocalDate;
import java.util.Random;
import javax.swing.JOptionPane;

public class Cliente {
    private String idCliente;
    private String nombreCompleto;
    private String telefono;
    private String correo;
    private String usuario;
    private String clave;
    private EstadoCliente estado;
    private Cuenta[] cuentas;
    private int numeroCuentasRegistradas;
    private Movimientos[] movimientos;
    private int contadorMovimientos;
    private int[][] tarjetaAcceso;

    public Cliente(String idCliente, String nombreCompleto, String telefono, String correo, String usuario, String clave) {
        this.idCliente = idCliente;
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.correo = correo;
        this.usuario = usuario;
        this.clave = clave;
        this.estado = EstadoCliente.ACTIVO;
        this.cuentas = new Cuenta[5];
        this.numeroCuentasRegistradas = 0;
        this.movimientos = new Movimientos[50];
        this.contadorMovimientos = 0;
        this.generarTarjetaAcceso();
    }

    public void agregarMovimiento(Movimientos movimiento) {
        if (contadorMovimientos < movimientos.length) {
            movimientos[contadorMovimientos] = movimiento;
            contadorMovimientos++;
        }
    }

    public String mostrarCuentasYMovimientos() {
        String resultado = "=== Cliente: " + nombreCompleto + " (" + idCliente + ") ===\n";
        
        if (numeroCuentasRegistradas == 0) {
            resultado += "No tiene cuentas registradas\n";
            return resultado;
        }

        for (int i = 0; i < numeroCuentasRegistradas; i++) {
            Cuenta cuenta = cuentas[i];
            resultado += "\nCuenta #" + (i+1) + ":\n";
            resultado += "Número: " + cuenta.getNumeroCuenta() + "\n";
            resultado += "Tipo: " + cuenta.getTipoCuenta() + "\n";
            resultado += "Saldo actual: " + cuenta.getSaldoInicial() + "\n";
            
            resultado += "Movimientos:\n";
            boolean tieneMovimientos = false;
            
            for (int j = 0; j < contadorMovimientos; j++) {
                Movimientos m = movimientos[j];
                if (m.getNumeroDeCuentaOrigen().equals(cuenta.getNumeroCuenta())) {
                    tieneMovimientos = true;
                    switch (m.getTipoDeMovimiento()) {
                        case DEPOSITO:
                            resultado += m.getInfoDeposito() + "\n";
                            break;
                        case RETIRO:
                            resultado += m.getInfoRetiro() + "\n";
                            break;
                        case TRANSFERENCIA:
                            resultado += m.getInfoTransferencia() + "\n";
                            break;
                        case COMPRA:
                            resultado += m.getInfoCompra() + "\n";
                            break;
                    }
                    resultado += "----------------\n";
                }
            }
            
            if (!tieneMovimientos) {
                resultado += "No hay movimientos en esta cuenta\n";
            }
        }
        return resultado;
    }
    public static void iniciarSesion(BancoGestor gestor) {
        boolean sesionIniciada = false;
        while (!sesionIniciada) {
            String usuario = JOptionPane.showInputDialog(null, "Ingrese su usuario:");
            if (usuario == null) {
                JOptionPane.showMessageDialog(null, "Operación cancelada. Volviendo al menú principal.");
                return;
            }

            Cliente cliente = gestor.buscarClientePorUsuario(usuario);
            if (cliente == null) {
                JOptionPane.showMessageDialog(null, "No hay ningún cliente con el usuario: " + usuario);
                continue;
            }

            if (cliente.getEstado() == EstadoCliente.INACTIVO) {
                JOptionPane.showMessageDialog(null, "Cliente está inactivo.");
                continue;
            }

            if (cliente.getClave() == null || cliente.getClave().isEmpty()) {
                boolean claveValida = false;
                while (!claveValida) {
                    String nuevaClave = JOptionPane.showInputDialog(null, 
                        "Primer inicio de sesión. Cree una nueva clave (mínimo 4 caracteres):");
                    
                    if (nuevaClave == null) {
                        JOptionPane.showMessageDialog(null, "Operación cancelada.");
                        return;
                    }
                    
                    if (nuevaClave.length() >= 4) {
                        cliente.setClave(nuevaClave);
                        claveValida = true;
                        JOptionPane.showMessageDialog(null, "Clave creada exitosamente.");
                    } else {
                        JOptionPane.showMessageDialog(null, "La clave debe tener al menos 4 caracteres.");
                    }
                }
            }

            boolean claveCorrecta = false;
            while (!claveCorrecta) {
                String clave = JOptionPane.showInputDialog(null, "Ingrese su clave de acceso:");
                if (clave == null) {
                    JOptionPane.showMessageDialog(null, "Operación cancelada. Volviendo al menú principal.");
                    return;
                }

                if (cliente.getClave().equals(clave)) {
                    JOptionPane.showMessageDialog(null, "Bienvenido al sistema, " + cliente.getNombreCompleto());
                    System.out.println("\nEsta es su tarjeta de acceso "+cliente.generarTarjetaAcceso());
                    
                    cliente.mostrarMenuCliente(gestor);
                    sesionIniciada = true;
                    claveCorrecta = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Clave incorrecta. Inténtelo de nuevo.");
                }
            }
        }
    }

    public void mostrarMenuCliente(BancoGestor gestor) {
       
        boolean volver = false;
         
        while (!volver) {
            
            String[] opciones = {"[REALIZAR TRANSACCIONES]", "[MIS CUENTAS]", "[ACTUALIZAR]", "[SALIR]"};
            
            int seleccion = JOptionPane.showOptionDialog(
                    null,
                    "Bienvenido, " + this.nombreCompleto  + "\nSeleccione una opción:",
                    "Menú de Cliente",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
            );

            if (seleccion == 0) {
                gestor.realizarTransaccion();
            } else if (seleccion == 1) {
                JOptionPane.showMessageDialog(null, "Funcionalidad de Transaccoines en desarrollo.");
            } else if (seleccion == 2) {
                JOptionPane.showMessageDialog(null, "Funcionalidad de Actualizar en desarrollo.");
            } else if (seleccion == 3) {
                volver = true;
                JOptionPane.showMessageDialog(null, "Saliendo del menú de cliente. ¡Hasta pronto!");
            } else {
                volver = true;
            }
        }
    }

    public boolean agregarCuenta(Cuenta nuevaCuenta) {
        if (numeroCuentasRegistradas < 5) {
            cuentas[numeroCuentasRegistradas] = nuevaCuenta;
            numeroCuentasRegistradas++;
            return true;
        }
        return false;
    }

    private int[][] generarTarjetaAcceso() {
        this.tarjetaAcceso = new int[4][5];
        Random rand = new Random();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                this.tarjetaAcceso[i][j] = rand.nextInt(10);
            }
        }
    return this.tarjetaAcceso;}

    // Getters y setters
    public String getIdCliente() { return idCliente; }
    public String getNombreCompleto() { return nombreCompleto; }
    public String getUsuario() { return usuario; }
    public String getClave() { return clave; }
    public EstadoCliente getEstado() { return estado; }
    public Cuenta[] getCuentas() { return cuentas; }
    public int getNumeroCuentasRegistradas() { return numeroCuentasRegistradas; }
    public void setClave(String clave) { this.clave = clave; }
}