/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal2;

import javax.swing.JOptionPane;

/**
 *
 * @author azoac
 */
public class BancoMenu {
public static void mostrarMenuBancario(BancoGestor gestor) {

      boolean volver = false;

       do {
            String opcion = JOptionPane.showInputDialog(
                "Menú Bancario:\n"
              + "1. Generar datos\n"
              + "2. Mostrar clientes\n"
              + "3. Mostrar cuentas y movimientos\n"
              + "4. Agregar nuevo cliente\n"
              + "5. Agregar nueva cuenta\n"
              + "6. Buscar cliente\n"
              + "7. Buscar cuenta\n"
              + "8. Generar reportes\n"
              + "9. Volver al menú principal"
            );
            
      int op = Integer.parseInt(opcion);
                switch (op) {
                    case 1:
                       JOptionPane.showMessageDialog(null,"Funcion en construccion perdone el inconveniente");

                        break;
                    case 2:
                         gestor.mostrarTodosClientes();
                        break;
                    case 3:
                         
                        gestor.mostrarTodasCuentasYMovimientos();

                        break;
                    case 4:
                        gestor.agregarCliente();
 
                        break;
                    case 5:
                        gestor.agregarNuevaCuenta();

                        break;
                    case 6:
                        JOptionPane.showMessageDialog(null,"Funcion en construccion perdone el inconveniente");

                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null,"Funcion en construccion perdone el inconveniente");

                        break;
                    case 8:
                        JOptionPane.showMessageDialog(null,"Funcion en construccion perdone el inconveniente");

                        break;
                    case 9:

                        volver = true;
                        JOptionPane.showMessageDialog(null,"Saliendo del menu bancario");
                        ProyectoFinal2.mostrarMenuPrincipal();
                       
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción no válida");
                } 
                     
    }while (!volver);
 }
}