/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal2;

/**
 *
 * @author azoac
 */
public class Cuenta {
    private String numeroCuenta;
    private Cliente duenoCuenta;
    private TipoCuenta tipoCuenta;
    private double saldoInicial;

    public Cuenta(String numeroCuenta, Cliente duenoCuenta, TipoCuenta tipoCuenta, double saldoInicial) {
        this.numeroCuenta = numeroCuenta;
        this.duenoCuenta = duenoCuenta;
        this.tipoCuenta = tipoCuenta;
        this.saldoInicial = saldoInicial;
    }

    public void setSaldoInicial(double saldoInicial) {
        this.saldoInicial = saldoInicial;
    }

    // Getters
    public String getNumeroCuenta() { return numeroCuenta; }
    public Cliente getDuenoCuenta() { return duenoCuenta; }
    public TipoCuenta getTipoCuenta() { return tipoCuenta; }
    public double getSaldoInicial() { return saldoInicial; }

   
}