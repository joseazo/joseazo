/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal2;

/**
 *
 * @author azoac
 */
import javax.swing.JOptionPane;

public class BancoGestor {
    private Cliente[] clientes = new Cliente[30];
    private int contadorClientes = 0;
    private int siguienteUsuarioNumero = 40;
    private int siguienteNumeroCuenta = 4710;

    public void agregarCliente() {
         if (contadorClientes >= 30) {
            JOptionPane.showMessageDialog(null, "No se pueden agregar más clientes. Límite alcanzado.");
            return;
        }

        // Validación del ID del cliente con do-while
        String idCliente;
        boolean idValido = false;
        do {
            idCliente = JOptionPane.showInputDialog("Ingrese ID del cliente:");
            if (idCliente == null) {
                JOptionPane.showMessageDialog(null, "Operación cancelada.");
                return;
            }
            idCliente = idCliente.trim();
            if (idCliente.length() == 0) {
                int respuesta = JOptionPane.showConfirmDialog(null, "El ID no puede estar vacío. ¿Desea intentar de nuevo?");
                if (respuesta != 1) return;
            } else if (buscarClientePorId(idCliente) != null) {
                int respuesta = JOptionPane.showConfirmDialog(null, "El ID ya existe. ¿Desea intentar con otro ID?");
                if (respuesta != 0) return;
            } else {
                idValido = true;
            }
        } while (!idValido);

        // Validación del nombre completo
        String nombreCompleto;
        do {
            nombreCompleto = JOptionPane.showInputDialog("Ingrese nombre completo:");
            if (nombreCompleto == null) {
                JOptionPane.showMessageDialog(null, "Operación cancelada.");
                return;
            }
            nombreCompleto = nombreCompleto.trim();
            if (nombreCompleto.length() == 0) {
                JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío.");
            }
        } while (nombreCompleto.length() == 0);

        // Validación del teléfono
        String telefono;
        boolean telefonoValido = false;
        do {
            telefono = JOptionPane.showInputDialog("Ingrese teléfono (Formato: 0000-0000):");
            if (telefono == null) {
                JOptionPane.showMessageDialog(null, "Operación cancelada.");
                return;
            }
            telefono = telefono.trim();
            if (telefono.length() != 9 || telefono.charAt(4) != '-') {
                JOptionPane.showMessageDialog(null, "Formato inválido. Debe ser 0000-0000.");
            } else {
                telefonoValido = true;
                for (int i = 0; i < telefono.length(); i++) {
                    if (i != 4 && !Character.isDigit(telefono.charAt(i))) {
                        telefonoValido = false;
                        JOptionPane.showMessageDialog(null, "El teléfono solo debe contener números y un guión.");
                        break;
                    }
                }
            }
        } while (!telefonoValido);

        // Validación del correo
        String correo;
        boolean correoValido = false;
        do {
            correo = JOptionPane.showInputDialog("Ingrese correo electrónico:");
            if (correo == null) {
                JOptionPane.showMessageDialog(null, "Operación cancelada.");
                return;
            }
            correo = correo.trim();
            if (correo.length() == 0) {
                JOptionPane.showMessageDialog(null, "El correo no puede estar vacío.");
            } else if (correo.indexOf('@') < 1 || correo.indexOf('.', correo.indexOf('@')) < correo.indexOf('@') + 2) {
                JOptionPane.showMessageDialog(null, "Correo no válido. Debe contener '@' y un dominio válido.");
            } else {
                correoValido = true;
            }
        } while (!correoValido);

        String primerNombre;
        if (nombreCompleto.contains(" ")) {
            primerNombre = nombreCompleto.substring(0, nombreCompleto.indexOf(" "));
        } else {
            primerNombre = nombreCompleto;
        }
        String usuario = primerNombre + siguienteUsuarioNumero++;
        
        Cliente nuevoCliente = new Cliente(idCliente, nombreCompleto, telefono, correo, usuario, "");
        clientes[contadorClientes++] = nuevoCliente;
        JOptionPane.showMessageDialog(null, "Cliente agregado:\nUsuario: " + usuario + 
            "\nLa clave se creará en el primer inicio de sesión.");
    }
    public void agregarNuevaCuenta() {
         if (contadorClientes == 0) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados en el sistema para agregar cuentas.");
            return;
        }

        Cliente clienteSeleccionado = null;
        String idCliente;
        boolean clienteEncontrado = false;

        do {
            idCliente = JOptionPane.showInputDialog(null, "Ingrese el ID del cliente al que desea agregar una cuenta:");
            if (idCliente == null) {
                JOptionPane.showMessageDialog(null, "Operación de agregar nueva cuenta cancelada.");
                return;
            }
            clienteSeleccionado = buscarClientePorId(idCliente);
            if (clienteSeleccionado == null) {
                int confirmResult = JOptionPane.showConfirmDialog(null, "¿Desea ingresar otro ID?" + "Cliente no encontrado");
                if (confirmResult != 0) { return; } 
            } else {
                clienteEncontrado = true;
            }
        } while (!clienteEncontrado);

        // Validar si el cliente ya tiene 5 cuentas
        while (clienteSeleccionado.getNumeroCuentasRegistradas() >= 5) {// Usando el literal 5
            int confirmResult = JOptionPane.showConfirmDialog(null, "El cliente ya tiene el número máximo de cuentas (5).\n¿Desea ingresar otro ID de cliente?");
            if (confirmResult != 0) { 
                JOptionPane.showMessageDialog(null, "Operación de agregar nueva cuenta cancelada.");
                return;
            }
            
            // Si elige "Ingresar otro ID", se vuelve a pedir el ID
            idCliente = JOptionPane.showInputDialog(null, "Ingrese el ID del cliente al que desea agregar una cuenta:");
            if (idCliente == null) {
                JOptionPane.showMessageDialog(null, "Operación de agregar nueva cuenta cancelada.");
                return;
            }
            clienteSeleccionado = buscarClientePorId(idCliente);
            if (clienteSeleccionado == null) {
                int confirmResult2 = JOptionPane.showConfirmDialog(null, "Cliente no encontrado. ¿Desea ingresar otro ID?");
                if (confirmResult2 != 0) { return; } 
            }
        }

        String numeroCuenta = "" + siguienteNumeroCuenta++; 
        TipoCuenta tipoCuenta = null;
        double saldoInicial = 0;
        boolean datosCuentaValidos = false;

        // Seleccionar tipo de cuenta
        String[] tipos = {"CORRIENTE", "AHORROS", "INVERSION", "PLANILLA"};
        int tipoSeleccion = JOptionPane.showOptionDialog(null, "Seleccione el tipo de cuenta:", "Tipo de Cuenta",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, tipos, tipos[0]);

        if (tipoSeleccion == -1) { 
            JOptionPane.showMessageDialog(null, "Operación de agregar nueva cuenta cancelada.");
            return;
        }

        switch (tipoSeleccion) {
            case 0:
                tipoCuenta = TipoCuenta.CORRIENTE;
                break;
            case 1:
                tipoCuenta = TipoCuenta.AHORROS;
                break;
            case 2:
                tipoCuenta = TipoCuenta.INVERSION;
                break;
            case 3:
                tipoCuenta = TipoCuenta.PLANILLA;
                break;
            default:
                JOptionPane.showMessageDialog(null, "Selección de tipo de cuenta no válida. Asignando AHORROS por defecto.");
                tipoCuenta = TipoCuenta.AHORROS; // Asignar un valor por defecto 
                break;
        }


        // Solicitar y validar saldo inicial 
        while (!datosCuentaValidos) {
            String saldoStr = JOptionPane.showInputDialog(null, "Ingrese el saldo inicial de la cuenta:");
            if (saldoStr == null) {
                JOptionPane.showMessageDialog(null, "Operación de agregar nueva cuenta cancelada.");
                return;
            }
            
            boolean currentSaldoAttemptValid = false;
            if (saldoStr.trim().length() == 0) {
                 int confirmResult = JOptionPane.showConfirmDialog(null, "El saldo inicial no puede estar vacío. ¿Desea ingresar otro Saldo?");
                if (confirmResult != 0) { return; } 
            } else {
                
             
                for (int i = 0; i < saldoStr.length(); i++) {
                    char c = saldoStr.charAt(i);
                    if (c == '-' && i == 0) {
                         
                    
                   
                    }
                }

               
                    saldoInicial = Double.parseDouble(saldoStr);
                    if (saldoInicial < 0) {
                        int confirmResult = JOptionPane.showConfirmDialog(null, "El saldo inicial no puede ser negativo. ¿Desea ingresar otro Saldo?");
                        if (confirmResult != 0) { 
                            JOptionPane.showMessageDialog(null, "Operación de agregar nueva cuenta cancelada.");
                            return;
                        }
                    } else {
                        currentSaldoAttemptValid = true;
                    }
                    }
                
            
            if (currentSaldoAttemptValid) {
                datosCuentaValidos = true;
            }
        }

      
    }


    public void mostrarTodosClientes() {
        if (contadorClientes == 0) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados");
            return;
        }

        String resultado = "--- LISTADO DE CLIENTES ---\n\n";
        for (int i = 0; i < contadorClientes; i++) {
            Cliente cliente = clientes[i];
            resultado += "CLIENTE " + (i+1) + ":\n";
            resultado += "ID: " + cliente.getIdCliente() + "\n";
            resultado += "Nombre: " + cliente.getNombreCompleto() + "\n";
            resultado += "Usuario: " + cliente.getUsuario() + "\n";
            resultado += "Estado: " + cliente.getEstado() + "\n";
            resultado += "Número de cuentas: " + cliente.getNumeroCuentasRegistradas() + "\n\n";
        }

        JOptionPane.showMessageDialog(null, resultado);
    }

    public void mostrarTodasCuentasYMovimientos() {
        if (contadorClientes == 0) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados");
            return;
        }

        String resultado = "=== REPORTE DE CUENTAS Y MOVIMIENTOS ===\n\n";
        for (int i = 0; i < contadorClientes; i++) {
            resultado += clientes[i].mostrarCuentasYMovimientos() + "\n";
        }

        JOptionPane.showMessageDialog(null, resultado);
    }

    public void realizarTransaccion() {
        if (contadorClientes == 0) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados");
            return;
        }

        String[] tipos = {"DEPÓSITO", "RETIRO", "TRANSFERENCIA", "COMPRA"};
        int tipo = JOptionPane.showOptionDialog(null, "Seleccione tipo de transacción:",
                "Tipo de Transacción", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, tipos, tipos[0]);

        if (tipo < 0) return;

        switch (tipo) {
            case 0: realizarDeposito(); break;
            case 1: realizarRetiro(); break;
            case 2: realizarTransferencia(); break;
            case 3: realizarCompra(); break;
        }
    }

    private void realizarDeposito() {
        String numeroCuenta = JOptionPane.showInputDialog("Ingrese número de cuenta:");
        if (numeroCuenta == null || numeroCuenta.trim().length() == 0) return;

        String montoStr = JOptionPane.showInputDialog("Ingrese monto a depositar:");
        if (montoStr == null || montoStr.trim().length() == 0) return;
        
        double monto = Double.parseDouble(montoStr);
        if (monto <= 0) {
            JOptionPane.showMessageDialog(null, "El monto debe ser positivo");
            return;
        }

        for (int i = 0; i < contadorClientes; i++) {
            for (int j = 0; j < clientes[i].getNumeroCuentasRegistradas(); j++) {
                Cuenta cuenta = clientes[i].getCuentas()[j];
                if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                    cuenta.setSaldoInicial(cuenta.getSaldoInicial() + monto);
                    Movimientos movimiento = Movimientos.crearDeposito(numeroCuenta, monto);
                    clientes[i].agregarMovimiento(movimiento);
                    JOptionPane.showMessageDialog(null, "Depósito realizado con éxito\nNuevo saldo: " + cuenta.getSaldoInicial());
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada");
    }

    private void realizarRetiro() {
        String numeroCuenta = JOptionPane.showInputDialog("Ingrese número de cuenta:");
        if (numeroCuenta == null || numeroCuenta.trim().length() == 0) return;

        String montoStr = JOptionPane.showInputDialog("Ingrese monto a retirar:");
        if (montoStr == null || montoStr.trim().length() == 0) return;
        
        double monto = Double.parseDouble(montoStr);
        if (monto <= 0) {
            JOptionPane.showMessageDialog(null, "El monto debe ser positivo");
            return;
        }

        for (int i = 0; i < contadorClientes; i++) {
            for (int j = 0; j < clientes[i].getNumeroCuentasRegistradas(); j++) {
                Cuenta cuenta = clientes[i].getCuentas()[j];
                if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                    if (cuenta.getSaldoInicial() < monto) {
                        JOptionPane.showMessageDialog(null, "Saldo insuficiente");
                        return;
                    }
                    cuenta.setSaldoInicial(cuenta.getSaldoInicial() - monto);
                    Movimientos movimiento = Movimientos.crearRetiro(numeroCuenta, monto);
                    clientes[i].agregarMovimiento(movimiento);
                    JOptionPane.showMessageDialog(null, "Retiro realizado con éxito\nNuevo saldo: " + cuenta.getSaldoInicial());
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada");
    }

    private void realizarTransferencia() {
        String cuentaOrigen = JOptionPane.showInputDialog("Ingrese número de cuenta origen:");
        if (cuentaOrigen == null || cuentaOrigen.trim().length() == 0) return;

        String cuentaDestino = JOptionPane.showInputDialog("Ingrese número de cuenta destino:");
        if (cuentaDestino == null || cuentaDestino.trim().length() == 0) return;

        String montoStr = JOptionPane.showInputDialog("Ingrese monto a transferir:");
        if (montoStr == null || montoStr.trim().length() == 0) return;
        
        double monto = Double.parseDouble(montoStr);
        if (monto <= 0) {
            JOptionPane.showMessageDialog(null, "El monto debe ser positivo");
            return;
        }

        // Buscar ambas cuentas
        Cuenta origen = null, destino = null;
        Cliente clienteOrigen = null, clienteDestino = null;

        for (int i = 0; i < contadorClientes; i++) {
            for (int j = 0; j < clientes[i].getNumeroCuentasRegistradas(); j++) {
                Cuenta cuenta = clientes[i].getCuentas()[j];
                if (cuenta.getNumeroCuenta().equals(cuentaOrigen)) {
                    origen = cuenta;
                    clienteOrigen = clientes[i];
                }
                if (cuenta.getNumeroCuenta().equals(cuentaDestino)) {
                    destino = cuenta;
                    clienteDestino = clientes[i];
                }
            }
        }

        if (origen == null || destino == null) {
            JOptionPane.showMessageDialog(null, "Una o ambas cuentas no fueron encontradas");
            return;
        }

        if (origen.getSaldoInicial() < monto) {
            JOptionPane.showMessageDialog(null, "Saldo insuficiente en cuenta origen");
            return;
        }

        // Realizar transferencia
        origen.setSaldoInicial(origen.getSaldoInicial() - monto);
        destino.setSaldoInicial(destino.getSaldoInicial() + monto);

        // Registrar movimientos
        Movimientos movimiento = Movimientos.crearTransferencia(cuentaOrigen, cuentaDestino, monto);
        clienteOrigen.agregarMovimiento(movimiento);
        if (clienteOrigen != clienteDestino) {
            clienteDestino.agregarMovimiento(movimiento);
        }

        JOptionPane.showMessageDialog(null, "Transferencia realizada con éxito\n" +
                "Cuenta origen (" + cuentaOrigen + ") nuevo saldo: " + origen.getSaldoInicial() + "\n" +
                "Cuenta destino (" + cuentaDestino + ") nuevo saldo: " + destino.getSaldoInicial());
    }

    private void realizarCompra() {
        String numeroCuenta = JOptionPane.showInputDialog("Ingrese número de cuenta:");
        if (numeroCuenta == null || numeroCuenta.trim().length() == 0) return;

        String montoStr = JOptionPane.showInputDialog("Ingrese monto de la compra:");
        if (montoStr == null || montoStr.trim().length() == 0) return;
        
        double monto = Double.parseDouble(montoStr);
        if (monto <= 0) {
            JOptionPane.showMessageDialog(null, "El monto debe ser positivo");
            return;
        }

        String detalle = JOptionPane.showInputDialog("Ingrese detalle de la compra:");
        if (detalle == null || detalle.trim().length() == 0) return;

        for (int i = 0; i < contadorClientes; i++) {
            for (int j = 0; j < clientes[i].getNumeroCuentasRegistradas(); j++) {
                Cuenta cuenta = clientes[i].getCuentas()[j];
                if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                    if (cuenta.getSaldoInicial() < monto) {
                        JOptionPane.showMessageDialog(null, "Saldo insuficiente");
                        return;
                    }
                    cuenta.setSaldoInicial(cuenta.getSaldoInicial() - monto);
                    Movimientos movimiento = Movimientos.crearCompra(numeroCuenta, monto, detalle);
                    clientes[i].agregarMovimiento(movimiento);
                    JOptionPane.showMessageDialog(null, "Compra realizada con éxito\nNuevo saldo: " + cuenta.getSaldoInicial());
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada");
    }

 private Cliente buscarClientePorId(String idCliente) {
        for (int i = 0; i < contadorClientes; i++) {
            if (clientes[i].getIdCliente().equals(idCliente)) {
                return clientes[i];
            }
        }
        return null;
    }

    public Cliente buscarClientePorUsuario(String usuario) {
        for (int i = 0; i < contadorClientes; i++) {
            if (clientes[i].getUsuario().equals(usuario)) {
                return clientes[i];
            }
        }
        return null;
    }
}
