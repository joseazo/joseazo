/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.proyectofinal2;

/**
 *
 * @author azoac
 */
public enum EstadoCliente {
    
ACTIVO,   // Cliente activo en el sistema
    INACTIVO  // Cliente inactivo
}