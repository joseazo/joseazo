/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal2;

/**
 *
 * @author azoac
 */
import java.time.LocalDate;

public class Movimientos {
    private static int siguienteNumeroTransaccion = 10000;
    
    private TipoDeMovimientos tipoDeMovimiento;
    private int numeroDeTransaccion;
    private String numeroDeCuentaOrigen;
    private String numeroDeCuentaDestino;
    private double monto;
    private LocalDate fecha;
    private String detalle;

    // Constructor para Depósito/Retiro
    private Movimientos(TipoDeMovimientos tipo, String numeroCuenta, double monto) {
        this.tipoDeMovimiento = tipo;
        this.numeroDeTransaccion = siguienteNumeroTransaccion++;
        this.numeroDeCuentaOrigen = numeroCuenta;
        this.monto = monto;
        this.fecha = LocalDate.now();
    }

    // Constructor para Transferencia
    private Movimientos(String cuentaOrigen, String cuentaDestino, double monto) {
        this.tipoDeMovimiento = TipoDeMovimientos.TRANSFERENCIA;
        this.numeroDeTransaccion = siguienteNumeroTransaccion++;
        this.numeroDeCuentaOrigen = cuentaOrigen;
        this.numeroDeCuentaDestino = cuentaDestino;
        this.monto = monto;
        this.fecha = LocalDate.now();
    }

    // Constructor para Compra
    private Movimientos(String numeroCuenta, double monto, String detalle) {
        this.tipoDeMovimiento = TipoDeMovimientos.COMPRA;
        this.numeroDeTransaccion = siguienteNumeroTransaccion++;
        this.numeroDeCuentaOrigen = numeroCuenta;
        this.monto = monto;
        this.fecha = LocalDate.now();
        this.detalle = detalle;
    }

    // Métodos  para cada tipo de movimiento
    public static Movimientos crearDeposito(String numeroCuenta, double monto) {
        return new Movimientos(TipoDeMovimientos.DEPOSITO, numeroCuenta, monto);
    }

    public static Movimientos crearRetiro(String numeroCuenta, double monto) {
        return new Movimientos(TipoDeMovimientos.RETIRO, numeroCuenta, monto);
    }

    public static Movimientos crearTransferencia(String cuentaOrigen, String cuentaDestino, double monto) {
        return new Movimientos(cuentaOrigen, cuentaDestino, monto);
    }

    public static Movimientos crearCompra(String numeroCuenta, double monto, String detalle) {
        return new Movimientos(numeroCuenta, monto, detalle);
    }

    // Métodos para mostrar información específica
    public String getInfoDeposito() {
        return "Depósito en efectivo - Transacción #" + numeroDeTransaccion + 
               "\nCuenta: " + numeroDeCuentaOrigen + 
               "\nMonto: +" + monto + 
               "\nFecha: " + fecha;
    }

    public String getInfoRetiro() {
        return "Retiro en efectivo - Transacción #" + numeroDeTransaccion + 
               "\nCuenta: " + numeroDeCuentaOrigen + 
               "\nMonto: -" + monto + 
               "\nFecha: " + fecha;
    }

    public String getInfoTransferencia() {
        return "Transferencia bancaria - Transacción #" + numeroDeTransaccion + 
               "\nCuenta origen: " + numeroDeCuentaOrigen + 
               "\nCuenta destino: " + numeroDeCuentaDestino + 
               "\nMonto: " + monto + 
               "\nFecha: " + fecha;
    }

    public String getInfoCompra() {
        return "Compra Online - Transacción #" + numeroDeTransaccion + 
               "\nCuenta: " + numeroDeCuentaOrigen + 
               "\nMonto: -" + monto + 
               "\nDetalle: " + detalle + 
               "\nFecha: " + fecha;
    }

    // Getters
    public TipoDeMovimientos getTipoDeMovimiento() { return tipoDeMovimiento; }
    public int getNumeroDeTransaccion() { return numeroDeTransaccion; }
    public String getNumeroDeCuentaOrigen() { return numeroDeCuentaOrigen; }
    public String getNumeroDeCuentaDestino() { return numeroDeCuentaDestino; }
    public double getMonto() { return monto; }
    public LocalDate getFecha() { return fecha; }
    public String getDetalle() { return detalle; }
}